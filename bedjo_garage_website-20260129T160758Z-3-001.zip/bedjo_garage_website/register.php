<?php
session_start();
include 'db_connect.php';

$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $conn->real_escape_string($_POST['email']);
    $username = $conn->real_escape_string($_POST['username']); // Tangkap username
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validasi input
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Format email tidak valid.";
    } elseif (empty($username) || strlen($username) < 3) { // Validasi username
        $error_message = "Username minimal 3 karakter.";
    } elseif (strlen($password) < 6) {
        $error_message = "Kata sandi minimal 6 karakter.";
    } elseif ($password !== $confirm_password) {
        $error_message = "Konfirmasi kata sandi tidak cocok.";
    } else {
        // Cek apakah email atau username sudah terdaftar
        $stmt_check = $conn->prepare("SELECT id FROM users WHERE email = ? OR username = ?");
        $stmt_check->bind_param("ss", $email, $username);
        $stmt_check->execute();
        $stmt_check->store_result();

        if ($stmt_check->num_rows > 0) {
            $error_message = "Email atau Username ini sudah terdaftar. Silakan gunakan yang lain.";
        } else {
            // Hash password sebelum disimpan
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Simpan user baru (tambahkan username)
            $stmt = $conn->prepare("INSERT INTO users (email, username, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $email, $username, $hashed_password);

            if ($stmt->execute()) {
                $success_message = "Akun berhasil dibuat! Silakan masuk.";
            } else {
                $error_message = "Gagal membuat akun. Silakan coba lagi.";
            }
        }
        $stmt_check->close();
        $stmt->close(); // Tutup stmt untuk insert jika sudah dibuka
    }
}

include 'header.php';
?>

<main class="main-content">
    <div class="container auth-form-container">
        <h2>Buat Akun Bedjo Garage</h2>
        <?php if (!empty($error_message)): ?>
            <p class="error-message"><?php echo $error_message; ?></p>
        <?php elseif (!empty($success_message)): ?>
            <p class="success-message"><?php echo $success_message; ?></p>
        <?php endif; ?>
        <form action="register.php" method="POST" class="auth-form">
            <div class="form-group">
                <input type="email" id="email" name="email" placeholder="Email" required>
            </div>
            <div class="form-group">
                <input type="text" id="username" name="username" placeholder="Username" required minlength="3">
            </div>
            <div class="form-group password-toggle">
                <input type="password" id="password" name="password" placeholder="Masukan kata sandi" required>
                <span class="toggle-password" onclick="togglePasswordVisibility('password')"><i class="fas fa-eye"></i></span>
            </div>
            <div class="form-group password-toggle">
                <input type="password" id="confirm_password" name="confirm_password" placeholder="Konfirmasi kata sandi" required>
                <span class="toggle-password" onclick="togglePasswordVisibility('confirm_password')"><i class="fas fa-eye"></i></span>
            </div>
            <button type="submit" class="btn btn-primary btn-full-width">Daftar Sekarang</button>
            <p class="auth-links">
                Sudah mempunyai akun? <a href="login.php">Masuk</a>
            </p>
        </form>
    </div>
</main>

<?php include 'footer.php'; ?>

<script>
function togglePasswordVisibility(id) {
    const input = document.getElementById(id);
    const icon = input.nextElementSibling.querySelector('i');
    if (input.type === "password") {
        input.type = "text";
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = "password";
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}
</script>