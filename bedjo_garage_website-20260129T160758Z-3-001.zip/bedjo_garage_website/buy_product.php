<?php
session_start();
include 'header.php';
include 'db_connect.php';

// Pastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_after_login'] = 'buy_product.php?product_id=' . $_GET['product_id'];
    header("Location: login.php");
    exit();
}

// Ambil ID produk dari URL dan pastikan itu adalah angka
$product_id = isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0;
if ($product_id <= 0) {
    die("ID Produk tidak valid.");
}

// Ambil detail produk dari database
$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->bind_param("i", $product_id);
$stmt->execute();
$result = $stmt->get_result();
$selected_product = $result->fetch_assoc();
$stmt->close();

if (!$selected_product) {
    die("Produk tidak ditemukan.");
}

// Buat catatan pesanan baru di tabel 'product_orders'
$order_code = 'ORD-PROD-' . time() . '-' . $selected_product['id'];
$user_id = $_SESSION['user_id'];
$total_price = $selected_product['price'];

$stmt_order = $conn->prepare("INSERT INTO product_orders (order_code, user_id, product_id, total_price, payment_status) VALUES (?, ?, ?, ?, 'pending')");
$stmt_order->bind_param("siid", $order_code, $user_id, $product_id, $total_price);
$stmt_order->execute();
$new_order_id = $conn->insert_id; // Dapatkan ID dari order yang baru dibuat
$stmt_order->close();


// --- SIMULASI INTEGRASI PAYMENT GATEWAY ---
$qris_image_url = 'gambar/placeholder_qris.png'; 
$expiry_time = date("d M Y, H:i", time() + (60 * 15));
// --- AKHIR SIMULASI ---

?>

<main class="main-content">
    <div class="container content-card" style="max-width: 500px; text-align: center;">
        <h2>Selesaikan Pembayaran Anda</h2>
        <p>Scan kode QRIS di bawah ini untuk membayar pesanan Anda.</p>
        <hr>

        <div class="order-summary">
            <h4>Detail Pesanan:</h4>
            <p><strong>Produk:</strong> <?php echo htmlspecialchars($selected_product['name']); ?></p>
            <p><strong>Total Bayar:</strong> <span class="product-price">Rp <?php echo number_format($selected_product['price'], 0, ',', '.'); ?></span></p>
            <p><strong>Order ID:</strong> <?php echo htmlspecialchars($order_code); ?></p>
        </div>
        
        <div class="qris-container">
            <img src="<?php echo $qris_image_url; ?>" alt="Scan QRIS untuk membayar" style="max-width: 100%; height: auto; border-radius: 8px;">
            <p style="font-size: 0.9em; color: #777;">Kode ini akan berakhir pada <?php echo $expiry_time; ?></p>
        </div>

        <div class="payment-instructions">
            <h4>Cara Pembayaran:</h4>
            <ol style="text-align: left; display: inline-block;">
                <li>Buka aplikasi e-wallet atau mobile banking Anda.</li>
                <li>Pilih opsi 'Bayar' atau 'Scan QR'.</li>
                <li>Scan kode QR di atas.</li>
                <li>Pastikan nominal pembayaran sudah sesuai.</li>
                <li>Masukkan PIN Anda dan selesaikan transaksi.</li>
            </ol>
        </div>

        <a href="konfirmasi.php?order_id=<?php echo $new_order_id; ?>" class="btn btn-primary" style="margin-top: 1.5rem;">
            Saya Sudah Membayar
        </a>
    </div>
</main>

<?php include 'footer.php'; ?>