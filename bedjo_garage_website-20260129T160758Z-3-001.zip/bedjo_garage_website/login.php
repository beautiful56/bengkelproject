<?php
session_start();
include 'db_connect.php';

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];

    // Query untuk mengambil user berdasarkan email (ambil juga username)
    $stmt = $conn->prepare("SELECT id, email, username, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['username'] = $user['username']; // Simpan username ke session!

            // Redirect jika ada redirect_after_login
            if (isset($_SESSION['redirect_after_login'])) {
                $redirect_url = $_SESSION['redirect_after_login'];
                unset($_SESSION['redirect_after_login']);
                header("Location: " . $redirect_url);
                exit();
            } else {
                header("Location: index.php"); // Redirect ke halaman utama setelah login
                exit();
            }
        } else {
            $error_message = "Email atau kata sandi salah.";
        }
    } else {
        $error_message = "Email atau kata sandi salah.";
    }
    $stmt->close();
}

include 'header.php';
?>

<main class="main-content">
    <div class="container auth-form-container">
        <h2>Masuk ke Bedjo Garage</h2>
        <?php if (!empty($error_message)): ?>
            <p class="error-message"><?php echo $error_message; ?></p>
        <?php endif; ?>
        <form action="login.php" method="POST" class="auth-form">
            <div class="form-group">
                <input type="email" id="email" name="email" placeholder="Email" required>
            </div>
            <div class="form-group password-toggle">
                <input type="password" id="password" name="password" placeholder="Masukan kata sandi" required>
                <span class="toggle-password" onclick="togglePasswordVisibility('password')"><i class="fas fa-eye"></i></span>
            </div>
            <button type="submit" class="btn btn-primary btn-full-width">Masuk</button>
            <p class="auth-links">
                Belum mempunyai akun? <a href="register.php">Daftar Sekarang</a>
            </p>
            <p class="auth-links">
                <a href="forgot_password.php">Lupa Kata Sandi?</a>
            </p>
        </form>
    </div>
</main>

<?php include 'footer.php'; ?>

<script>
function togglePasswordVisibility(id) {
    const input = document.getElementById(id);
    const icon = input.nextElementSibling.querySelector('i');
    if (input.type === "password") {
        input.type = "text";
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = "password";
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}
</script>