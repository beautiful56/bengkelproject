<?php
// logout.php
// File ini akan menghapus sesi pengguna dan mengarahkannya kembali ke halaman utama.

// Pastikan session dimulai HANYA jika belum dimulai
// Ini penting agar session_unset dan session_destroy bisa berfungsi
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Hapus semua variabel sesi
session_unset();

// Hancurkan sesi sepenuhnya
// Ini akan menghapus cookie sesi juga
session_destroy();

// Arahkan pengguna kembali ke halaman utama setelah logout
// Menggunakan path absolut untuk memastikan redirect selalu benar
// Pastikan "bedjo_garage_website" sesuai dengan nama folder proyek Anda di htdocs/www
header("Location: /bedjo_garage_website/index.php");
exit(); // Penting untuk menghentikan eksekusi skrip setelah header redirect
?>