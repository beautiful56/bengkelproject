<?php
session_start();
include 'header.php';
include 'db_connect.php';

$order_id_db = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;
$order_code_display = 'TIDAK DIKETAHUI';

if ($order_id_db > 0) {
    // Ambil order code dari DB untuk ditampilkan
    $stmt = $conn->prepare("SELECT order_code FROM product_orders WHERE id = ?");
    $stmt->bind_param("i", $order_id_db);
    $stmt->execute();
    $result = $stmt->get_result();
    if($order = $result->fetch_assoc()){
        $order_code_display = $order['order_code'];
    }
    $stmt->close();
}
?>

<main class="main-content">
    <div class="container content-card" style="max-width: 600px; text-align: center;">
        <div style="font-size: 4rem; color: #28a745;">
            <i class="fas fa-check-circle"></i>
        </div>
        <h2 style="margin-top: 1rem;">Terima Kasih!</h2>
        <p>Kami sedang memverifikasi pembayaran Anda. Anda akan menerima notifikasi jika pembayaran telah berhasil dikonfirmasi.</p>
        <hr>
        <p>Nomor Pesanan Anda:</p>
        <p><strong><?php echo htmlspecialchars($order_code_display); ?></strong></p>
        <br>
        <a href="index.php" class="btn btn-secondary">Kembali ke Halaman Utama</a>
    </div>
</main>

<?php include 'footer.php'; ?>