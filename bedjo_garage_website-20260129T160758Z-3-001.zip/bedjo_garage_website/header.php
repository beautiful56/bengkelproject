<?php
// Pastikan session dimulai HANYA jika belum dimulai
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bedjo Garage - Performa Tanpa Batas</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

    <header class="main-header">
        <div class="container header-top">
            <nav class="mobile-nav-toggle">
                <button class="hamburger-menu" aria-label="Toggle Navigation">
                    <i class="fas fa-bars"></i>
                </button>
            </nav>
            </div>

        <nav class="main-icon-navigation">
            <div class="container nav-links-wrapper">
                <ul>
                    <li class="nav-logo-item">
                        <a href="index.php">
                            <img src="gambar/logo.jpeg" alt="Bedjo Garage Logo" class="nav-logo-img">
                            <span>BEDJO GARAGE</span>
                        </a>
                    </li>
                    <li class="dark-mode-nav-item"> <div class="dark-mode-toggle">
                            <input type="checkbox" id="darkModeSwitch" class="dark-mode-switch">
                            <label for="darkModeSwitch" class="dark-mode-label"></label>
                        </div>
                    </li>
                    <li>
                        <a href="index.php">
                            <i class="fas fa-home"></i>
                            <span>HOME</span>
                        </a>
                    </li>
                    <li>
                        <a href="layanan.php">
                            <i class="fas fa-th-large"></i>
                            <span>LAYANAN</span>
                        </a>
                    </li>
                    <li>
                        <a href="booking.php">
                            <i class="fas fa-calendar-alt"></i>
                            <span>BOOKING</span>
                        </a>
                    </li>
                    <li>
                        <a href="promo.php">
                            <i class="fas fa-tags"></i>
                            <span>PROMO</span>
                        </a>
                    </li>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <?php
                            $display_name = $_SESSION['username'] ?? '';
                            if (empty($display_name) && isset($_SESSION['user_email'])) {
                                $parts = explode('@', $_SESSION['user_email']);
                                $display_name = $parts[0];
                            } elseif (empty($display_name)) {
                                $display_name = 'User';
                            }
                        ?>
                        <li>
                            <a href="my_bookings.php">
                                <i class="fas fa-user-circle"></i>
                                <span><?php echo htmlspecialchars(strtoupper($display_name)); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="logout.php">
                                <i class="fas fa-sign-out-alt"></i>
                                <span>LOGOUT</span>
                            </a>
                        </li>
                    <?php else: ?>
                        <li>
                            <a href="login.php">
                                <i class="fas fa-sign-in-alt"></i>
                                <span>MASUK</span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </nav>
    </header>

    <div class="mobile-overlay-menu" id="mobileOverlayMenu">
        <button class="close-overlay-btn" aria-label="Tutup Menu">
            <i class="fas fa-times"></i>
        </button>
        <div class="overlay-menu-content">
            <div class="overlay-logo-section">
                <img src="gambar/logo.jpeg" alt="Bedjo Garage Logo">
            </div>
            <ul>
                <li><a href="index.php"><i class="fas fa-home"></i> HOME</a></li>
                <li><a href="layanan.php"><i class="fas fa-th-large"></i> LAYANAN</a></li>
                <li><a href="booking.php"><i class="fas fa-calendar-alt"></i> BOOKING</a></li>
                <li><a href="promo.php"><i class="fas fa-tags"></i> PROMO</a></li>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li><a href="my_bookings.php"><i class="fas fa-user-circle"></i> AKUN SAYA</a></li>
                    <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> LOGOUT</a></li>
                <?php else: ?>
                    <li><a href="login.php"><i class="fas fa-sign-in-alt"></i> MASUK</a></li>
                    <li><a href="register.php"><i class="fas fa-user-plus"></i> DAFTAR</a></li>
                <?php endif; ?>
                <li class="mobile-dark-mode-toggle">
                    <span><i class="fas fa-moon"></i> Mode Gelap</span>
                    <input type="checkbox" id="mobileDarkModeSwitch" class="dark-mode-switch">
                    <label for="mobileDarkModeSwitch" class="dark-mode-label"></label>
                </li>
            </ul>
        </div>
    </div>