<?php
session_start();
include 'db_connect.php';

$message = '';
$message_type = ''; // 'success' or 'error'
$token_valid = false;
$token = '';

// Ambil token dari URL
if (isset($_GET['token']) && !empty($_GET['token'])) {
    $token = $conn->real_escape_string($_GET['token']);

    // Verifikasi token dan waktu kedaluwarsa
    $stmt = $conn->prepare("SELECT id, reset_token_expiry FROM users WHERE reset_token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        $expiry_time = strtotime($user['reset_token_expiry']);
        if (time() < $expiry_time) {
            $token_valid = true;
        } else {
            $message = "Tautan reset telah kedaluwarsa. Silakan minta tautan baru.";
            $message_type = 'error';
        }
    } else {
        $message = "Tautan reset tidak valid.";
        $message_type = 'error';
    }
    $stmt->close();
} else {
    $message = "Tautan reset tidak ditemukan.";
    $message_type = 'error';
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $token_valid) {
    $new_password = $_POST['new_password'];
    $confirm_new_password = $_POST['confirm_new_password'];
    $token_post = $conn->real_escape_string($_POST['token']); // Ambil token dari hidden input

    if ($token_post !== $token) { // Cek ulang token dari POST vs GET
        $message = "Terjadi kesalahan keamanan. Silakan coba lagi.";
        $message_type = 'error';
        $token_valid = false; // Batalkan proses jika token tidak cocok
    } elseif (strlen($new_password) < 6) {
        $message = "Kata sandi baru minimal 6 karakter.";
        $message_type = 'error';
    } elseif ($new_password !== $confirm_new_password) {
        $message = "Konfirmasi kata sandi baru tidak cocok.";
        $message_type = 'error';
    } else {
        // Hash password baru
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

        // Update password dan hapus token reset
        $stmt_update = $conn->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_token_expiry = NULL WHERE reset_token = ?");
        $stmt_update->bind_param("ss", $hashed_password, $token_post); // Gunakan token dari POST

        if ($stmt_update->execute()) {
            $message = "Kata sandi Anda berhasil diatur ulang. Silakan masuk.";
            $message_type = 'success';
            $token_valid = false; // Invalidasi form setelah password diupdate
        } else {
            $message = "Gagal mengatur ulang kata sandi. Silakan coba lagi.";
            $message_type = 'error';
        }
        $stmt_update->close();
    }
}

include 'header.php';
?>

<main class="main-content">
    <div class="container auth-form-container">
        <h2>Atur Ulang Kata Sandi</h2>
        <?php if (!empty($message)): ?>
            <p class="<?php echo $message_type; ?>-message"><?php echo $message; ?></p>
        <?php endif; ?>

        <?php if ($token_valid): ?>
            <form action="reset_password_form.php?token=<?php echo htmlspecialchars($token); ?>" method="POST" class="auth-form">
                <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                <div class="form-group password-toggle">
                    <input type="password" id="new_password" name="new_password" placeholder="Kata Sandi Baru" required>
                    <span class="toggle-password" onclick="togglePasswordVisibility('new_password')"><i class="fas fa-eye"></i></span>
                </div>
                <div class="form-group password-toggle">
                    <input type="password" id="confirm_new_password" name="confirm_new_password" placeholder="Konfirmasi Kata Sandi Baru" required>
                    <span class="toggle-password" onclick="togglePasswordVisibility('confirm_new_password')"><i class="fas fa-eye"></i></span>
                </div>
                <button type="submit" class="btn btn-primary btn-full-width">Ubah Kata Sandi</button>
            </form>
        <?php else: ?>
            <p class="auth-links">
                <a href="forgot_password.php">Minta link reset password baru</a>
            </p>
        <?php endif; ?>
    </div>
</main>

<?php include 'footer.php'; ?>

<script>
function togglePasswordVisibility(id) {
    const input = document.getElementById(id);
    const icon = input.nextElementSibling.querySelector('i');
    if (input.type === "password") {
        input.type = "text";
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = "password";
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}
</script>