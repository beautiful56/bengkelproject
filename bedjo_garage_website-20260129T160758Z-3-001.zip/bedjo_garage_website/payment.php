<?php
// payment.php
session_start();
include 'db_connect.php';

// Pastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_after_login'] = 'payment.php'; // Jika belum login, simpan halaman ini
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$booking_id = $_GET['booking_id'] ?? null;
$message = '';
$message_type = '';

// =========================================================================
// PENTING: UBAH PATH GAMBAR QRIS INI SESUAI LOKASI FILE ANDA
// Contoh: 'gambar/qris_bedjo_garage.jpeg' jika Anda menamainya qris_bedjo_garage.jpeg
// =========================================================================
$qris_image_path = 'gambar/qris_bedjo_garage.jpeg'; // <--- PASTIKAN PATH INI BENAR


if (!$booking_id) {
    $message = "ID Booking tidak ditemukan. Silakan kembali ke halaman booking.";
    $message_type = 'error';
    // Anda bisa redirect user ke my_bookings.php jika tidak ada booking_id
    // header("Location: my_bookings.php"); exit();
} else {
    // Verifikasi booking_id ini milik user yang login dan statusnya 'Pending Payment'
    $stmt = $conn->prepare("SELECT service_type, booking_date, status FROM bookings WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $booking_id, $user_id);
    $stmt->execute();
    $booking_details = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$booking_details) {
        $message = "Booking tidak ditemukan atau bukan milik Anda.";
        $message_type = 'error';
    } elseif ($booking_details['status'] !== 'Pending Payment' && $booking_details['status'] !== 'Pending Verification' && $booking_details['status'] !== 'Rejected') {
        // Jika sudah Confirmed atau status lain yang bukan pending, beri info
        $message = "Booking ini sudah berstatus: " . htmlspecialchars($booking_details['status']) . ".";
        $message_type = 'info';
        if ($booking_details['status'] === 'Confirmed') {
             $message_type = 'success'; // Jika sudah dikonfirmasi, anggap sukses
             $message = "Pembayaran untuk booking ini sudah Berhasil Dikonfirmasi! Terima kasih.";
        }
        // Redirect user ke my_bookings.php jika status bukan Pending Payment
        // header("Location: my_bookings.php"); exit();
    }
}

// Handle Proof of Payment Upload
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['payment_proof']) && $booking_id && $booking_details) {
    // Pastikan booking statusnya masih Pending Payment sebelum mengunggah
    if ($booking_details['status'] !== 'Pending Payment' && $booking_details['status'] !== 'Rejected') {
        $message = "Booking ini tidak lagi dalam status menunggu pembayaran atau sudah diverifikasi.";
        $message_type = 'info';
    } else {
        $target_dir = "uploads/payment_proofs/"; // Folder untuk menyimpan bukti pembayaran
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true); // Buat folder jika belum ada (pastikan izin tulis)
        }

        $file_extension = strtolower(pathinfo($_FILES['payment_proof']['name'], PATHINFO_EXTENSION));
        $allowed_extensions = array('jpg', 'jpeg', 'png', 'pdf'); // Izinkan PDF juga

        if (!in_array($file_extension, $allowed_extensions)) {
            $message = "Hanya file JPG, JPEG, PNG, & PDF yang diizinkan.";
            $message_type = 'error';
        } elseif ($_FILES['payment_proof']['size'] > 5 * 1024 * 1024) { // Max 5MB
            $message = "Ukuran file terlalu besar. Maksimal 5MB.";
            $message_type = 'error';
        } else {
            // Buat nama file unik (misal: proof_BOOKINGID_TIMESTAMP.ext)
            $new_filename = "proof_" . $booking_id . "_" . time() . "." . $file_extension;
            $target_file = $target_dir . $new_filename;

            if (move_uploaded_file($_FILES['payment_proof']['tmp_name'], $target_file)) {
                // Simpan info bukti pembayaran ke database
                $stmt_insert_proof = $conn->prepare("INSERT INTO payment_proofs (booking_id, user_id, image_filename, upload_path, verification_status) VALUES (?, ?, ?, ?, 'pending')");
                $stmt_insert_proof->bind_param("iiss", $booking_id, $user_id, $new_filename, $target_file);

                if ($stmt_insert_proof->execute()) {
                    // Update status booking menjadi 'Pending Verification' di tabel bookings
                    $stmt_update_booking = $conn->prepare("UPDATE bookings SET status = 'Pending Verification' WHERE id = ?");
                    $stmt_update_booking->bind_param("i", $booking_id);
                    $stmt_update_booking->execute();
                    $stmt_update_booking->close();

                    $message = "Bukti pembayaran berhasil diunggah! Pembayaran Anda akan segera diverifikasi.";
                    $message_type = 'success';
                    // Redirect untuk mencegah resubmission form dan menampilkan pesan sukses
                    header("Location: payment.php?booking_id=" . $booking_id . "&status=upload_success");
                    exit();
                } else {
                    $message = "Gagal menyimpan informasi bukti pembayaran ke database.";
                    $message_type = 'error';
                    unlink($target_file); // Hapus file yang sudah diupload jika gagal DB
                }
                $stmt_insert_proof->close();
            } else {
                $message = "Gagal mengunggah file. Silakan coba lagi.";
                $message_type = 'error';
            }
        }
    }
}

// Tampilkan pesan sukses setelah redirect upload
if (isset($_GET['status']) && $_GET['status'] == 'upload_success') {
    $message = "Pembayaran Berhasil! Bukti pembayaran Anda berhasil diunggah dan sedang menunggu verifikasi.";
    $message_type = 'success';
}


include 'header.php';
?>

<main class="main-content">
    <div class="container payment-page-container">
        <h1>Pembayaran Booking</h1>
        <?php if (!empty($message)): ?>
            <p class="status-message <?php echo $message_type; ?>-message"><?php echo $message; ?></p>
        <?php endif; ?>

        <?php
        // Hanya tampilkan detail pembayaran dan form jika booking_id valid DAN statusnya masih membutuhkan pembayaran/verifikasi
        if ($booking_id && $booking_details && ($booking_details['status'] === 'Pending Payment' || $booking_details['status'] === 'Pending Verification' || $booking_details['status'] === 'Rejected')): ?>
            <div class="payment-details-summary">
                <p><strong>Booking untuk:</strong> <?php echo htmlspecialchars($booking_details['service_type']); ?></p>
                <p><strong>Tanggal:</strong> <?php echo date('d M Y', strtotime($booking_details['booking_date'])); ?></p>
                <p><strong>Status Saat Ini:</strong> <span class="booking-status <?php echo strtolower(str_replace(' ', '-', $booking_details['status'])); ?>"><?php echo htmlspecialchars($booking_details['status']); ?></span></p>
                <p class="small-text">Silakan lakukan pembayaran sesuai harga yang tertera saat booking.</p>
            </div>

            <div class="qris-section">
                <h2>Pembayaran Via QRIS</h2>
                <p>Scan QR Code di bawah ini untuk menyelesaikan pembayaran Anda.</p>
                <img src="<?php echo htmlspecialchars($qris_image_path); ?>" alt="QRIS Code Pembayaran" class="qris-image">
                <p class="qris-instruction">Pastikan jumlah yang ditransfer sesuai dengan total harga booking Anda.</p>
            </div>

            <div class="upload-proof-section">
                <h2>Unggah Bukti Pembayaran</h2>
                <p>Setelah melakukan pembayaran, mohon unggah bukti transfer/pembayaran Anda di sini.</p>
                <form action="payment.php?booking_id=<?php echo htmlspecialchars($booking_id); ?>" method="POST" enctype="multipart/form-data" class="upload-form">
                    <div class="form-group">
                        <label for="payment_proof">Pilih File Bukti Pembayaran (JPG, PNG, PDF, maks 5MB):</label>
                        <input type="file" id="payment_proof" name="payment_proof" accept="image/jpeg, image/png, application/pdf" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-full-width">Unggah Bukti</button>
                </form>
            </div>
        <?php else: // Jika booking tidak valid, atau statusnya sudah Confirmed ?>
             <p class="info-message">Terjadi kesalahan atau pembayaran untuk booking ini sudah diverifikasi.</p>
        <?php endif; ?>

        <div class="payment-action-buttons">
             <a href="my_bookings.php" class="btn btn-secondary">Lihat Booking Saya</a>
             <a href="index.php" class="btn btn-secondary">Kembali ke Beranda</a>
        </div>
    </div>
</main>

<?php include 'footer.php'; ?>