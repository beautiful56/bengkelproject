<?php
session_start();
include 'db_connect.php';

// Pastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Ambil informasi user dari session
$user_id = $_SESSION['user_id'];
$user_email = $_SESSION['user_email'];
$username_from_session = $_SESSION['username'];

// Ambil data user dari DB, termasuk profile_picture_path dan username terbaru
$stmt_user_data = $conn->prepare("SELECT email, username, profile_picture_path FROM users WHERE id = ?");
$stmt_user_data->bind_param("i", $user_id);
$stmt_user_data->execute();
$user_profile_data = $stmt_user_data->get_result()->fetch_assoc();
$stmt_user_data->close();

if (!$user_profile_data) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}
$username = $user_profile_data['username'] ?? explode('@', $user_email)[0];
$profile_picture_path = $user_profile_data['profile_picture_path'];

// --- Menentukan tab/bagian yang aktif ---
$current_tab = $_GET['tab'] ?? 'overview';

// --- Variabel untuk pesan sukses/error (umum untuk semua form) ---
$global_message = '';
$global_message_type = '';


// ======================================================================
// LOGIKA PEMROSESAN DATA UNTUK SETIAP BAGIAN
// ======================================================================

// --- Logika untuk 'list-motor' ---
$user_motors = [];
if ($current_tab === 'list-motor' || $current_tab === 'add-motor') {
    $stmt_motors = $conn->prepare("SELECT id, make, model, license_plate FROM user_motors WHERE user_id = ? ORDER BY created_at DESC");
    $stmt_motors->bind_param("i", $user_id);
    $stmt_motors->execute();
    $result_motors = $stmt_motors->get_result();
    if ($result_motors->num_rows > 0) {
        while ($row = $result_motors->fetch_assoc()) {
            $user_motors[] = $row;
        }
    }
    $stmt_motors->close();

    // Handle "Tambah Motor" submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_motor'])) {
        $make = $conn->real_escape_string($_POST['motor_make']);
        $model = $conn->real_escape_string($_POST['motor_model']);
        $license_plate = $conn->real_escape_string($_POST['motor_license_plate']);

        if (empty($make) || empty($model) || empty($license_plate)) {
            $global_message = "Mohon lengkapi semua detail motor.";
            $global_message_type = 'error';
        } else {
            $stmt_add_motor = $conn->prepare("INSERT INTO user_motors (user_id, make, model, license_plate) VALUES (?, ?, ?, ?)");
            $stmt_add_motor->bind_param("isss", $user_id, $make, $model, $license_plate);
            if ($stmt_add_motor->execute()) {
                $global_message = "Motor berhasil ditambahkan!";
                $global_message_type = 'success';
                header("Location: my_bookings.php?tab=list-motor&status=motor_added");
                exit();
            } else {
                $global_message = "Gagal menambahkan motor. Plat nomor mungkin sudah terdaftar.";
                $global_message_type = 'error';
            }
            $stmt_add_motor->close();
        }
    }
    // Cek pesan dari redirect setelah berhasil tambah motor
    if (isset($_GET['status']) && $_GET['status'] === 'motor_added') {
        $global_message = "Motor berhasil ditambahkan!";
        $global_message_type = 'success';
    }
}


// --- Logika untuk 'activity' (Riwayat Servis) ---
$bookings = [];
if ($current_tab === 'activity') {
    $stmt_bookings = $conn->prepare("SELECT id, service_type, booking_date, booking_time, vehicle_make, vehicle_model, license_plate, notes, status, created_at FROM bookings WHERE user_id = ? ORDER BY created_at DESC");
    $stmt_bookings->bind_param("i", $user_id);
    $stmt_bookings->execute();
    $result_bookings = $stmt_bookings->get_result();
    if ($result_bookings->num_rows > 0) {
        while ($row = $result_bookings->fetch_assoc()) {
            $bookings[] = $row;
        }
    } else {
        $global_message = "Anda belum memiliki riwayat servis atau booking saat ini.";
        $global_message_type = 'info';
    }
    $stmt_bookings->close();
}


// --- Logika untuk 'manage_account' (Edit Profile) ---
$account_update_message = '';
$account_message_type = '';

if ($current_tab === 'manage_account') {
    // Data user sudah diambil di awal file: $user_profile_data

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_profile'])) {
        $new_username = $conn->real_escape_string($_POST['username']);
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_new_password = $_POST['confirm_new_password'];

        $stmt_user_pass = $conn->prepare("SELECT password FROM users WHERE id = ?");
        $stmt_user_pass->bind_param("i", $user_id);
        $stmt_user_pass->execute();
        $user_data_for_pass = $stmt_user_pass->get_result()->fetch_assoc();
        $stmt_user_pass->close();

        if (!$user_data_for_pass || !password_verify($current_password, $user_data_for_pass['password'])) {
            $account_update_message = "Kata sandi saat ini salah.";
            $account_message_type = 'error';
        } else {
            $update_query_parts = [];
            $update_params = [];
            $param_types = "";
            $updates_made = false;

            if (!empty($new_username) && $new_username !== $user_profile_data['username']) {
                $stmt_check_username = $conn->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
                $stmt_check_username->bind_param("si", $new_username, $user_id);
                $stmt_check_username->execute();
                $stmt_check_username->store_result();
                if ($stmt_check_username->num_rows > 0) {
                    $account_update_message = "Username sudah digunakan. Silakan pilih username lain.";
                    $account_message_type = 'error';
                } else {
                    $update_query_parts[] = "username = ?";
                    $update_params[] = $new_username;
                    $param_types .= "s";
                    $updates_made = true;
                    $_SESSION['username'] = $new_username;
                    $username = $new_username;
                }
                $stmt_check_username->close();
            }

            if (empty($account_update_message) && !empty($new_password)) {
                if (strlen($new_password) < 6) {
                    $account_update_message = "Kata sandi baru minimal 6 karakter.";
                    $account_message_type = 'error';
                } elseif ($new_password !== $confirm_new_password) {
                    $account_update_message = "Konfirmasi kata sandi baru tidak cocok.";
                    $account_message_type = 'error';
                } else {
                    $hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);
                    $update_query_parts[] = "password = ?";
                    $update_params[] = $hashed_new_password;
                    $param_types .= "s";
                    $updates_made = true;
                }
            }

            if (empty($account_update_message) && isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
                $target_dir = "uploads/avatars/";
                if (!is_dir($target_dir)) {
                    mkdir($target_dir, 0777, true);
                }

                $file_extension = strtolower(pathinfo($_FILES['profile_picture']['name'], PATHINFO_EXTENSION));
                $allowed_extensions = array('jpg', 'jpeg', 'png', 'gif');

                if (!in_array($file_extension, $allowed_extensions)) {
                    $account_update_message = "Hanya JPG, JPEG, PNG, GIF untuk gambar profil.";
                    $account_message_type = 'error';
                } elseif ($_FILES['profile_picture']['size'] > 2 * 1024 * 1024) {
                    $account_update_message = "Ukuran gambar profil terlalu besar. Maksimal 2MB.";
                    $account_message_type = 'error';
                } else {
                    $new_avatar_filename = "avatar_" . $user_id . "_" . time() . "." . $file_extension;
                    $target_avatar_path = $target_dir . $new_avatar_filename;

                    if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $target_avatar_path)) {
                        $update_query_parts[] = "profile_picture_path = ?";
                        $update_params[] = $target_avatar_path;
                        $param_types .= "s";
                        $updates_made = true;

                        if ($profile_picture_path && file_exists($profile_picture_path) && strpos($profile_picture_path, 'placeholder.com') === false) {
                            unlink($profile_picture_path);
                        }
                        $profile_picture_path = $target_avatar_path;
                    } else {
                        $account_update_message = "Gagal mengunggah gambar profil.";
                        $account_message_type = 'error';
                    }
                }
            }

            if (empty($account_update_message) && $updates_made) {
                $update_query_str = "UPDATE users SET " . implode(", ", $update_query_parts) . " WHERE id = ?";
                $update_params[] = $user_id;
                $param_types .= "i";

                $stmt_update_user = $conn->prepare($update_query_str);
                $stmt_update_user->bind_param($param_types, ...$update_params);

                if ($stmt_update_user->execute()) {
                    $account_update_message = "Profil berhasil diperbarui!";
                    $account_message_type = 'success';
                    header("Location: my_bookings.php?tab=manage_account&status=updated");
                    exit();
                } else {
                    $account_update_message = "Gagal memperbarui profil. Silakan coba lagi.";
                    $account_message_type = 'error';
                }
                $stmt_update_user->close();
            } elseif (empty($account_update_message) && !$updates_made) {
                 $account_update_message = "Tidak ada perubahan yang dilakukan.";
                 $account_message_type = 'info';
            }
        }
    }
    if (isset($_GET['status']) && $_GET['status'] === 'updated') {
        $account_update_message = "Profil berhasil diperbarui!";
        $account_message_type = 'success';
    }
}


include 'header.php';
?>

<main class="main-content">
    <div class="container user-profile-page">

        <div class="profile-header-info">
            <img src="<?php echo htmlspecialchars($profile_picture_path ?: 'https://via.placeholder.com/80x80?text=User'); ?>" alt="User Avatar" class="profile-avatar">
            <span class="profile-username"><?php echo htmlspecialchars($username); ?></span>
        </div>

        <div class="profile-section notification-section">
            <div class="section-heading">
                <h3>Notifikasi</h3>
                <span class="notification-count">0</span>
            </div>
            <p class="section-description">Tidak ada notifikasi baru.</p>
        </div>

        <div class="profile-section motor-list-section">
            <div class="section-heading">
                <i class="fas fa-motorcycle"></i>
                <h3>List Motor</h3>
            </div>
            <p class="section-description">Menampilkan data motor anda.</p>

            <div class="motor-list-content">
                <?php if ($current_tab === 'add-motor'): // Tampilkan form tambah motor ?>
                    <div id="add-motor-form-view" class="detail-view-content">
                        <h2>Tambah Motor Baru</h2>
                        <?php if (!empty($global_message)): ?>
                            <p class="<?php echo $global_message_type; ?>-message"><?php echo $global_message; ?></p>
                        <?php endif; ?>
                        <form action="my_bookings.php?tab=add-motor" method="POST" class="auth-form">
                            <input type="hidden" name="add_motor" value="1">
                            <div class="form-group">
                                <label for="motor_make">Merk Motor:</label>
                                <input type="text" id="motor_make" name="motor_make" placeholder="Contoh: Honda" required>
                            </div>
                            <div class="form-group">
                                <label for="motor_model">Model Motor:</label>
                                <input type="text" id="motor_model" name="motor_model" placeholder="Contoh: Vario 150" required>
                            </div>
                            <div class="form-group">
                                <label for="motor_license_plate">Plat Nomor:</label>
                                <input type="text" id="motor_license_plate" name="motor_license_plate" placeholder="Contoh: B 1234 ABC" required>
                            </div>
                            <button type="submit" class="btn btn-primary btn-full-width">Simpan Motor</button>
                            <a href="my_bookings.php" class="btn btn-secondary btn-full-width mt-3">Batal</a>
                        </form>
                    </div>
                <?php else: // Tampilkan daftar motor ?>
                    <div class="motor-list">
                        <?php if (empty($user_motors)): ?>
                            <p class="info-message">Anda belum menambahkan motor. Klik "Tambah motor" untuk menambahkan motor Anda.</p>
                        <?php else: ?>
                            <?php foreach ($user_motors as $motor): ?>
                                <div class="list-item motor-item">
                                    <span><?php echo htmlspecialchars($motor['make'] . ' ' . $motor['model'] . ' ' . $motor['license_plate']); ?></span>
                                    <div class="item-actions">
                                        <button class="btn-edit-motor">Edit</button>
                                        <a href="#" class="list-item-btn"><i class="fas fa-chevron-right"></i></a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <a href="my_bookings.php?tab=add-motor" class="add-motor-btn list-item">
                        <i class="fas fa-plus-circle"></i> Tambah motor
                        <i class="fas fa-chevron-right"></i>
                    </a>
                <?php endif; ?>
            </div>
        </div>


        <div class="profile-section activity-section">
            <div class="section-heading">
                <i class="fas fa-calendar-alt"></i>
                <h3>Aktivitas</h3>
            </div>
            <p class="section-description">Data riwayat service di bengkel Bedjo Garage.</p>

            <div class="section-list">
                <a href="my_bookings.php?tab=activity" class="list-item">
                    Riwayat Servis
                    <i class="fas fa-chevron-right"></i>
                </a>
                <a href="my_bookings.php?tab=reminders" class="list-item">
                    Reminder Servis
                    <i class="fas fa-chevron-right"></i>
                </a>
            </div>
        </div>

        <div class="profile-section manage-account-section">
            <div class="section-heading">
                <i class="fas fa-user-circle"></i>
                <h3>Kelola akun</h3>
            </div>
            <p class="section-description">Data dan Informasi.</p>

            <div class="section-list">
                <a href="my_bookings.php?tab=manage_account" class="list-item">
                    Edit profile
                    <i class="fas fa-user-edit"></i>
                    <i class="fas fa-chevron-right"></i>
                </a>
                <a href="#" class="list-item">
                    Masukkan Kode Referral
                    <i class="fas fa-code"></i>
                    <i class="fas fa-chevron-right"></i>
                </a>
                <a href="logout.php" class="list-item">
                    Log out
                    <i class="fas fa-sign-out-alt"></i>
                    <i class="fas fa-chevron-right"></i>
                </a>
            </div>
        </div>

        <?php if ($current_tab !== 'overview'): // Hanya tampilkan detail section jika bukan overview ?>
            <div class="content-detail-section">
                <?php
                // Menampilkan pesan global dari submission form di semua bagian detail
                if (!empty($global_message)): ?>
                    <p class="<?php echo $global_message_type; ?>-message"><?php echo $global_message; ?></p>
                <?php endif; ?>

                <?php if ($current_tab === 'activity'): ?>
                    <div id="activity-history-section" class="detail-view-content">
                        <h2>Riwayat Servis Anda</h2>
                        <?php if (empty($bookings)): ?>
                            <p class="info-message">Anda belum memiliki riwayat servis.</p>
                        <?php else: ?>
                            <div class="bookings-list">
                                <?php foreach ($bookings as $booking): ?>
                                    <div class="booking-card">
                                        <h3><?php echo htmlspecialchars($booking['service_type']); ?></h3>
                                        <p><strong>Tanggal:</strong> <?php echo date('d M Y', strtotime($booking['booking_date'])); ?></p>
                                        <p><strong>Kategori CC:</strong> <?php echo htmlspecialchars($booking['booking_time']); ?></p>
                                        <p><strong>Kendaraan:</strong> <?php echo htmlspecialchars($booking['vehicle_make'] . ' ' . $booking['vehicle_model']); ?> (Plat: <?php echo htmlspecialchars($booking['license_plate']); ?>)</p>
                                        <p><strong>Catatan:</strong> <?php echo htmlspecialchars($booking['notes'] ?: '-'); ?></p>
                                        <p><strong>Status:</strong> <span class="booking-status <?php echo strtolower(str_replace(' ', '-', $booking['status'])); ?>"><?php echo htmlspecialchars($booking['status']); ?></span></p>
                                        <?php if ($booking['status'] === 'Pending Payment' || $booking['status'] === 'Rejected'): ?>
                                            <a href="payment.php?booking_id=<?php echo $booking['id']; ?>" class="btn btn-primary btn-sm mt-3">Lanjutkan Pembayaran</a>
                                        <?php elseif ($booking['status'] === 'Pending Verification'): ?>
                                            <p class="small-info-text">Menunggu verifikasi pembayaran...</p>
                                        <?php endif; ?>
                                        <p class="booking-created">Dibuat pada: <?php echo date('d M Y H:i', strtotime($booking['created_at'])); ?></p>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                        <a href="my_bookings.php" class="btn btn-secondary mt-3">Kembali ke Profil Utama</a>
                    </div>

                <?php elseif ($current_tab === 'reminders'): ?>
                    <div id="reminders-view" class="detail-view-content">
                        <h2>Pengingat Servis Anda</h2>
                        <?php if (!empty($reminder_message)): ?>
                            <p class="<?php echo $reminder_message_type; ?>-message"><?php echo $reminder_message; ?></p>
                        <?php endif; ?>

                        <div class="add-reminder-form-section">
                            <h3>Tambahkan Pengingat Baru</h3>
                            <form action="my_bookings.php?tab=reminders" method="POST" class="auth-form">
                                <input type="hidden" name="add_reminder" value="1">
                                <div class="form-group">
                                    <label for="motor_id">Pilih Motor (Opsional):</label>
                                    <select id="motor_id" name="motor_id">
                                        <option value="general">-- Pengingat Umum --</option>
                                        <?php foreach ($user_motors_for_reminders as $motor): ?>
                                            <option value="<?php echo htmlspecialchars($motor['id']); ?>">
                                                <?php echo htmlspecialchars($motor['make'] . ' ' . $motor['model'] . ' (' . $motor['license_plate'] . ')'); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="reminder_date">Tanggal Pengingat:</label>
                                    <input type="date" id="reminder_date" name="reminder_date" required min="<?php echo date('Y-m-d'); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="reminder_notes">Catatan:</label>
                                    <textarea id="reminder_notes" name="reminder_notes" rows="3" placeholder="Contoh: Ganti oli, Periksa ban juga"></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary btn-full-width">Tambahkan Pengingat</button>
                            </form>
                        </div>

                        <hr>

                        <div class="existing-reminders-section">
                            <h3>Daftar Pengingat</h3>
                            <?php if (empty($service_reminders)): ?>
                                <p class="info-message">Anda belum memiliki pengingat servis yang tersimpan.</p>
                            <?php else: ?>
                                <div class="reminders-list">
                                    <?php foreach ($service_reminders as $reminder): ?>
                                        <div class="reminder-item">
                                            <div class="reminder-date-info">
                                                <i class="fas fa-bell"></i>
                                                <span><?php echo date('d M Y', strtotime($reminder['reminder_date'])); ?></span>
                                            </div>
                                            <div class="reminder-details">
                                                <p><strong>Motor:</strong> <?php echo htmlspecialchars($reminder['make'] ? $reminder['make'] . ' ' . $reminder['model'] . ' (' . $reminder['license_plate'] . ')' : 'Umum'); ?></p>
                                                <p><strong>Catatan:</strong> <?php echo htmlspecialchars($reminder['reminder_notes'] ?: '-'); ?></p>
                                            </div>
                                            <div class="reminder-actions">
                                                </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <a href="my_bookings.php" class="btn btn-secondary mt-3">Kembali ke Profil Utama</a>
                    </div>

                <?php elseif ($current_tab === 'manage_account'): ?>
                    <div id="manage-account-form-view" class="detail-view-content">
                        <h2>Edit Profil Anda</h2>
                        <?php if (!empty($account_update_message)): ?>
                            <p class="<?php echo $account_message_type; ?>-message"><?php echo $account_update_message; ?></p>
                        <?php endif; ?>
                        <form action="my_bookings.php?tab=manage_account" method="POST" enctype="multipart/form-data" class="auth-form profile-manage-form">
                            <input type="hidden" name="save_profile" value="1">
                            <div class="form-group profile-avatar-upload">
                                <label for="profile_picture">Foto Profil:</label>
                                <img src="<?php echo htmlspecialchars($profile_picture_path ?: 'https://via.placeholder.com/80x80?text=User'); ?>" alt="Current Avatar" class="current-profile-avatar">
                                <input type="file" id="profile_picture" name="profile_picture" accept="image/*">
                                <small>Maksimal 2MB, JPG, PNG, GIF.</small>
                            </div>
                            <div class="form-group">
                                <label for="email">Email Anda:</label>
                                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user_email); ?>" disabled>
                                <small>Email tidak dapat diubah.</small>
                            </div>
                            <div class="form-group">
                                <label for="username">Username:</label>
                                <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($username); ?>" required minlength="3">
                            </div>
                            <hr>
                            <h3>Ubah Kata Sandi</h3>
                            <p class="small-text">Isi bagian ini hanya jika Anda ingin mengubah kata sandi.</p>
                            <div class="form-group password-toggle">
                                <label for="current_password">Kata Sandi Saat Ini:</label>
                                <input type="password" id="current_password" name="current_password" required>
                                 <span class="toggle-password" onclick="togglePasswordVisibility('current_password')"><i class="fas fa-eye"></i></span>
                            </div>
                            <div class="form-group password-toggle">
                                <label for="new_password">Kata Sandi Baru:</label>
                                <input type="password" id="new_password" name="new_password" placeholder="Biarkan kosong jika tidak ingin mengubah" minlength="6">
                                 <span class="toggle-password" onclick="togglePasswordVisibility('new_password')"><i class="fas fa-eye"></i></span>
                            </div>
                            <div class="form-group password-toggle">
                                <label for="confirm_new_password">Konfirmasi Kata Sandi Baru:</label>
                                <input type="password" id="confirm_new_password" name="confirm_new_password" placeholder="Ulangi kata sandi baru">
                                 <span class="toggle-password" onclick="togglePasswordVisibility('confirm_new_password')"><i class="fas fa-eye"></i></span>
                            </div>
                            <button type="submit" name="save_profile" class="btn btn-primary btn-full-width">Simpan Perubahan</button>
                        </form>
                        <a href="my_bookings.php" class="btn btn-secondary mt-3">Kembali ke Profil</a>
                    </div>
                <?php elseif ($current_tab === 'add-motor'): ?>
                    <div id="add-motor-form-view" class="detail-view-content">
                        <h2>Tambah Motor Baru</h2>
                        <?php if (!empty($global_message)): ?>
                            <p class="<?php echo $global_message_type; ?>-message"><?php echo $global_message; ?></p>
                        <?php endif; ?>
                        <form action="my_bookings.php?tab=add-motor" method="POST" class="auth-form">
                            <input type="hidden" name="add_motor" value="1">
                            <div class="form-group">
                                <label for="motor_make">Merk Motor:</label>
                                <input type="text" id="motor_make" name="motor_make" placeholder="Contoh: Honda" required>
                            </div>
                            <div class="form-group">
                                <label for="motor_model">Model Motor:</label>
                                <input type="text" id="motor_model" name="motor_model" placeholder="Contoh: Vario 150" required>
                            </div>
                            <div class="form-group">
                                <label for="motor_license_plate">Plat Nomor:</label>
                                <input type="text" id="motor_license_plate" name="motor_license_plate" placeholder="Contoh: B 1234 ABC" required>
                            </div>
                            <button type="submit" class="btn btn-primary btn-full-width">Simpan Motor</button>
                            <a href="my_bookings.php?tab=list-motor" class="btn btn-secondary btn-full-width mt-3">Batal</a>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</main>

<?php include 'footer.php'; ?>