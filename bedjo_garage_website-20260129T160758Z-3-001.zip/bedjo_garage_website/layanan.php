<?php include 'header.php'; ?>

    <main class="main-content">
        <div class="container">
            <h1>Layanan Kami di Bedjo Garage</h1>
            <p>Kami menyediakan berbagai layanan terbaik untuk semua motor Anda:</p>

            <div class="layanan-list">
                <div class="layanan-item">
                    <h3>Full Service</h3>
                    <p>Pembersihan menyeluruh, pengecekan komponen vital, penggantian oli, filter, busi, dan penyetelan.</p>
                    <a href="booking.php?service=Full%20Service" class="btn btn-primary">Booking Full Service</a>
                </div>
                <div class="layanan-item">
                    <h3>Reguler Service</h3>
                    <p>Servis rutin meliputi pengecekan dasar, penggantian oli, dan pembersihan ringan.</p>
                    <a href="booking.php?service=Reguler%20Service" class="btn btn-primary">Booking Reguler Service</a>
                </div>
            </div>
        </div>
    </main>

<?php include 'footer.php'; ?>