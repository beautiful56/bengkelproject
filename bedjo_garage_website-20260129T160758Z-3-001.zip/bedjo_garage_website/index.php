<?php
include 'header.php'; // header.php sudah punya session_start()
?>

    <section class="hero-section">
        <div class="container hero-content">
            <div class="carousel-wrapper">
                <div class="carousel-track">
                    <div class="carousel-item">
                        <div class="hero-text">
                            <span class="dot-pattern left-dots"></span>
                            <span class="big-text">FULL SERVICE</span>
                            <span class="dot-pattern right-dots"></span>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="hero-text">
                            <span class="dot-pattern left-dots"></span>
                            <span class="big-text">REGULER SERVICE</span>
                            <span class="dot-pattern right-dots"></span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="carousel-nav">
                <button class="carousel-arrow left-arrow" aria-label="Previous Slide">&lt;</button>
                <div class="carousel-dots">
                    <span class="dot active" data-slide="0"></span>
                    <span class="dot" data-slide="1"></span>
                </div>
                <button class="carousel-arrow right-arrow" aria-label="Next Slide">&gt;</button>
            </div>
        </div>
    </section>

    <main class="main-content">
        <div class="container">
            <section class="welcome-section">
                <?php
                    // Ambil username dari session
                    $display_name = $_SESSION['username'] ?? '';

                    // Jika username kosong atau tidak ada di session (misal user lama), gunakan bagian depan email
                    if (empty($display_name) && isset($_SESSION['user_email'])) {
                        $parts = explode('@', $_SESSION['user_email']);
                        $display_name = $parts[0]; // Ambil bagian sebelum '@'
                    } elseif (empty($display_name)) {
                        $display_name = 'User'; // Default jika keduanya tidak ada (tidak login)
                    }
                ?>
                <h1>Selamat Datang, <?php echo htmlspecialchars($display_name); ?> di Bedjo Garage!</h1>
                <p>Performa Tanpa Batas.</p>
                <p>Disini anda bisa melakukan booking dan membeli sparepart terbaru</p>
            </section>

            <section class="action-cards">
                <div class="card card-layanan">
                    <h2>LAYANAN</h2>
                    <a href="layanan.php" class="btn btn-primary">Semua Layanan Bedjo Garage &rarr;</a>
                </div>
                <div class="card card-produk">
                    <h2>PRODUK</h2>
                    <a href="produk.php" class="btn btn-primary">Produk Bedjo Garage &rarr;</a>
                </div>
            </section>
        </div>
    </main>

<?php include 'footer.php'; ?>