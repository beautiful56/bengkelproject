<?php
// Pastikan session dimulai HANYA jika belum dimulai
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include 'header.php'; // Sertakan header untuk tampilan
?>

<main class="main-content">
    <div class="container content-card">
        <h1>Promo Spesial Bedjo Garage!</h1>
        <hr>
        <p>Nantikan berbagai penawaran menarik dari kami.</p>

        <div class="promo-content" style="text-align: center; margin-top: 2rem;">
            <i class="fas fa-tags fa-3x" style="color: #ccc; margin-bottom: 1rem;"></i>
            <p><strong>Belum ada promo yang tersedia saat ini.</strong></p>
            <p>Kunjungi halaman ini secara berkala untuk update terbaru!</p>
        </div>
    </div>
</main>

<?php include 'footer.php'; // Menggunakan footer.php agar konsisten ?>