document.addEventListener('DOMContentLoaded', () => {
    // --- Global Toggle Password Visibility Function ---
    // Fungsi ini didefinisikan sekali dan dapat diakses dari mana saja di window
    window.togglePasswordVisibility = function(id) {
        const input = document.getElementById(id);
        if (!input) {
            console.error(`Input with ID "${id}" not found for password toggle.`);
            return;
        }
        // Pastikan ikon berada di dalam elemen span yang langsung setelah input
        const iconContainer = input.nextElementSibling;
        if (!iconContainer || !iconContainer.querySelector('i')) {
            console.error(`Toggle icon container not found or icon missing for input ID "${id}".`);
            return;
        }
        const icon = iconContainer.querySelector('i');

        if (input.type === "password") {
            input.type = "text";
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
        } else {
            input.type = "password";
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
        }
    };


    // --- HAMBURGER MENU / MOBILE OVERLAY FUNCTIONALITY ---
    const hamburger = document.querySelector('.hamburger-menu');
    const mobileOverlayMenu = document.getElementById('mobileOverlayMenu');
    const closeOverlayBtn = document.querySelector('.close-overlay-btn');

    if (hamburger && mobileOverlayMenu && closeOverlayBtn) {
        hamburger.addEventListener('click', () => {
            mobileOverlayMenu.classList.add('active');
            // Opsional: tambahkan class ke body untuk mencegah scroll saat menu terbuka
            document.body.style.overflow = 'hidden';
        });

        closeOverlayBtn.addEventListener('click', () => {
            mobileOverlayMenu.classList.remove('active');
            document.body.style.overflow = ''; // Kembalikan scroll
        });

        // Tutup menu jika klik di luar area konten (opsional)
        mobileOverlayMenu.addEventListener('click', (e) => {
            // Pastikan yang diklik adalah background overlay itu sendiri, bukan konten di dalamnya
            if (e.target === mobileOverlayMenu) {
                mobileOverlayMenu.classList.remove('active');
                document.body.style.overflow = '';
            }
        });
    } else {
        console.warn("Peringatan: Elemen hamburger/overlay menu tidak ditemukan. Fungsionalitas mungkin tidak aktif.");
    }


    // --- DARK MODE FUNCTIONALITY ---
    const darkModeSwitch = document.getElementById('darkModeSwitch'); // Desktop switch
    const mobileDarkModeSwitch = document.getElementById('mobileDarkModeSwitch'); // Mobile switch

    // Fungsi untuk menerapkan mode gelap
    function applyDarkMode(isDark) {
        if (isDark) {
            document.body.classList.add('dark-mode');
        } else {
            document.body.classList.remove('dark-mode');
        }
    }

    // Cek preferensi dari localStorage saat halaman dimuat
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        applyDarkMode(true);
        // Pastikan switch diatur ke checked, jika elemennya ada
        if (darkModeSwitch) darkModeSwitch.checked = true;
        if (mobileDarkModeSwitch) mobileDarkModeSwitch.checked = true;
    } else {
        applyDarkMode(false);
        // Pastikan switch diatur ke unchecked, jika elemennya ada
        if (darkModeSwitch) darkModeSwitch.checked = false;
        if (mobileDarkModeSwitch) mobileDarkModeSwitch.checked = false;
    }

    // Event listener untuk desktop switch
    if (darkModeSwitch) {
        darkModeSwitch.addEventListener('change', () => {
            if (darkModeSwitch.checked) {
                applyDarkMode(true);
                localStorage.setItem('theme', 'dark');
                if (mobileDarkModeSwitch) mobileDarkModeSwitch.checked = true; // Sinkronkan switch mobile
            } else {
                applyDarkMode(false);
                localStorage.setItem('theme', 'light');
                if (mobileDarkModeSwitch) mobileDarkModeSwitch.checked = false; // Sinkronkan switch mobile
            }
        });
    }

    // Event listener untuk mobile switch
    if (mobileDarkModeSwitch) {
        mobileDarkModeSwitch.addEventListener('change', () => {
            if (mobileDarkModeSwitch.checked) {
                applyDarkMode(true);
                localStorage.setItem('theme', 'dark');
                if (darkModeSwitch) darkModeSwitch.checked = true; // Sinkronkan switch desktop
            } else {
                applyDarkMode(false);
                localStorage.setItem('theme', 'light');
                if (darkModeSwitch) darkModeSwitch.checked = false; // Sinkronkan switch desktop
            }
        });
    }


    // --- CAROUSEL FUNCTIONALITY ---
    const carouselTrack = document.querySelector('.carousel-track');
    const carouselItems = document.querySelectorAll('.carousel-item');
    const leftArrow = document.querySelector('.left-arrow');
    const rightArrow = document.querySelector('.right-arrow');
    const dotsContainer = document.querySelector('.carousel-dots');
    const dots = document.querySelectorAll('.carousel-dots .dot');

    // Pastikan semua elemen carousel ditemukan dan ada setidaknya 2 item untuk di-geser
    if (carouselTrack && carouselItems.length > 0 && leftArrow && rightArrow && dotsContainer && dots.length > 0) {
        if (carouselItems.length < 2) {
            // Sembunyikan panah dan dot jika hanya ada 1 atau kurang item
            leftArrow.style.display = 'none';
            rightArrow.style.display = 'none';
            dotsContainer.style.display = 'none';
        } else {
            let currentIndex = 0;
            const totalItems = carouselItems.length;

            function goToSlide(index) {
                if (index < 0) {
                    currentIndex = totalItems - 1; // Kembali ke slide terakhir
                } else if (index >= totalItems) {
                    currentIndex = 0; // Kembali ke slide pertama
                } else {
                    currentIndex = index; // Pindah ke indeks yang ditentukan
                }
                const offset = -currentIndex * 100; // Hitung pergeseran
                carouselTrack.style.transform = `translateX(${offset}%)`;
                updateDots();
            }

            function updateDots() {
                dots.forEach((dot, index) => {
                    if (index === currentIndex) {
                        dot.classList.add('active');
                    } else {
                        dot.classList.remove('active');
                    }
                });
            }
            leftArrow.addEventListener('click', () => goToSlide(currentIndex - 1));
            rightArrow.addEventListener('click', () => goToSlide(currentIndex + 1));
            dotsContainer.addEventListener('click', (e) => {
                if (e.target.classList.contains('dot')) {
                    goToSlide(parseInt(e.target.dataset.slide));
                }
            });
            goToSlide(0); // Inisialisasi carousel
        }
    } else {
        console.warn('Peringatan: Elemen-elemen penting carousel tidak ditemukan atau kurang dari 2 item. Carousel mungkin tidak berfungsi.');
    }


    // --- Multi-Step Booking Form Functionality ---
    const step1 = document.getElementById('step1');
    const step2 = document.getElementById('step2');
    const nextStepBtn = document.getElementById('nextStep');
    const prevStepBtn = document.getElementById('prevStep');
    const bookingForm = document.getElementById('bookingForm');

    // --- Price Calculation Elements ---
    const serviceSelect = document.getElementById('service_id');
    const engineCcSelect = document.getElementById('engine_cc');
    const finalPriceDisplay = document.querySelector('.final-price');

    // Fungsi untuk menghitung dan memperbarui harga
    function updatePrice() {
        let basePrice = 0;
        // Pastikan serviceSelect ada sebelum mengakses propertinya
        const selectedOption = serviceSelect ? serviceSelect.options[serviceSelect.selectedIndex] : null;

        if (selectedOption && selectedOption.dataset.basePrice) {
            basePrice = parseFloat(selectedOption.dataset.basePrice);
        }

        // Pastikan engineCcSelect ada sebelum mengakses propertinya
        const engineCc = engineCcSelect ? engineCcSelect.value : '';
        let additionalPrice = 0;

        if (engineCc === 'above_150cc') {
            additionalPrice = 100000;
        }

        const totalPrice = basePrice + additionalPrice;
        // Pastikan finalPriceDisplay ada sebelum memperbarui kontennya
        if (finalPriceDisplay) {
             finalPriceDisplay.textContent = `Rp ${totalPrice.toLocaleString('id-ID')}`; // Format ke Rupiah
        }
    }

    // Tambahkan event listener untuk perubahan pada dropdown service dan kapasitas mesin (jika elemen ada)
    if (serviceSelect) serviceSelect.addEventListener('change', updatePrice);
    if (engineCcSelect) engineCcSelect.addEventListener('change', updatePrice);
    updatePrice(); // Inisialisasi harga saat halaman dimuat (jika elemen ada)


    // Logika navigasi antar langkah form booking
    if (step1 && step2 && nextStepBtn && prevStepBtn && bookingForm) {
        nextStepBtn.addEventListener('click', () => {
            // Validasi dasar untuk Step 1 sebelum melanjutkan
            const serviceId = document.getElementById('service_id').value;
            const bookingDate = document.getElementById('booking_date').value;
            const engineCc = document.getElementById('engine_cc').value;

            if (serviceId && bookingDate && engineCc) {
                step1.classList.add('hidden');
                step2.classList.remove('hidden');
            } else {
                alert('Mohon lengkapi pilihan Layanan, Tanggal, dan Kapasitas Mesin.');
            }
        });

        prevStepBtn.addEventListener('click', () => {
            step2.classList.add('hidden');
            step1.classList.remove('hidden');
        });

        // Optional: Client-side validation sebelum submit form (lebih tangguh)
        // bookingForm.addEventListener('submit', (e) => {
        //     // Tambahkan validasi sisi klien yang lebih komprehensif untuk semua bidang di sini
        //     // Jika validasi gagal, e.preventDefault(); dan tampilkan pesan
        // });

    } else {
        console.warn("Peringatan: Elemen-elemen form booking multi-langkah tidak ditemukan. Fungsionalitas mungkin tidak aktif.");
    }
});

/* ==========================================================
   LOGIKA UNTUK BOOKING FORM MULTI-STEP
   ========================================================== */
document.addEventListener('DOMContentLoaded', function() {
    const nextStepBtn = document.getElementById('nextStep');
    const prevStepBtn = document.getElementById('prevStep');
    const step1 = document.getElementById('step1');
    const step2 = document.getElementById('step2');
    const stepper1 = document.getElementById('stepper-1');
    const stepper2 = document.getElementById('stepper-2');
    const bookingForm = document.getElementById('bookingForm');

    // Pastikan semua elemen ada sebelum menambahkan event listener
    if (nextStepBtn && prevStepBtn && step1 && step2 && stepper1 && stepper2) {
        
        nextStepBtn.addEventListener('click', function() {
            // Validasi sederhana sebelum lanjut
            let isValid = true;
            const requiredFields = step1.querySelectorAll('[required]');
            requiredFields.forEach(field => {
                if (!field.value) {
                    isValid = false;
                    field.style.borderColor = '#dc3545'; // Merah jika kosong
                } else {
                    field.style.borderColor = ''; // Kembali normal jika diisi
                }
            });

            if (isValid) {
                step1.style.display = 'none';
                step2.style.display = 'block';
                stepper1.classList.remove('active');
                stepper1.classList.add('completed');
                stepper2.classList.add('active');
            } else {
                alert('Mohon lengkapi semua field yang wajib diisi sebelum melanjutkan.');
            }
        });

        prevStepBtn.addEventListener('click', function() {
            step1.style.display = 'block';
            step2.style.display = 'none';
            stepper2.classList.remove('active');
            stepper1.classList.add('active');
            stepper1.classList.remove('completed');
        });
    }

    // Kalkulasi harga otomatis
    const serviceSelect = document.getElementById('service_id');
    const ccSelect = document.getElementById('engine_cc');
    const priceDisplay = document.querySelector('.final-price');

    function calculatePrice() {
        if (!serviceSelect || !ccSelect || !priceDisplay) return;

        const selectedService = serviceSelect.options[serviceSelect.selectedIndex];
        const basePrice = parseFloat(selectedService.dataset.basePrice) || 0;
        
        let finalPrice = basePrice;
        
        if (ccSelect.value === 'above_150cc' && basePrice > 0) {
            finalPrice += 100000;
        }
        
        priceDisplay.textContent = 'Rp ' + finalPrice.toLocaleString('id-ID');
    }

    if (serviceSelect) serviceSelect.addEventListener('change', calculatePrice);
    if (ccSelect) ccSelect.addEventListener('change', calculatePrice);

});
/* ==========================================================
   LOGIKA UNTUK AUTO-SUBMIT FORM FILTER PRODUK
   ========================================================== */
document.addEventListener('DOMContentLoaded', function() {
    const sortFilter = document.getElementById('sort-filter');
    const filterForm = document.getElementById('filter-form');

    if (sortFilter && filterForm) {
        sortFilter.addEventListener('change', function() {
            // Ketika pilihan dropdown diubah, langsung submit form-nya
            filterForm.submit();
        });
    }
});