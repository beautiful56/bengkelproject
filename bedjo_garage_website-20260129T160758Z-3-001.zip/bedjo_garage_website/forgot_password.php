<?php
session_start();
include 'db_connect.php';

$message = '';
$message_type = ''; // 'success' or 'error'

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $conn->real_escape_string($_POST['email']);

    // Cek apakah email terdaftar
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 1) {
        // Email ditemukan, buat token reset
        $token = bin2hex(random_bytes(32)); // Token acak
        $expiry = date("Y-m-d H:i:s", strtotime('+1 hour')); // Token berlaku 1 jam

        $stmt_update = $conn->prepare("UPDATE users SET reset_token = ?, reset_token_expiry = ? WHERE email = ?");
        $stmt_update->bind_param("sss", $token, $expiry, $email);
        
        if ($stmt_update->execute()) {
            // --- KIRIM EMAIL RESET PASSWORD ---
            $reset_link = "http://localhost/bedjo_garage_website/reset_password_form.php?token=" . $token; // Ubah URL ini
            $to = $email;
            $subject = "Reset Kata Sandi Bedjo Garage Anda";
            $headers = "From: no-reply@bedjogarage.com\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

            $email_body = "<html><body>";
            $email_body .= "<p>Anda menerima email ini karena ada permintaan reset kata sandi untuk akun Anda di Bedjo Garage.</p>";
            $email_body .= "<p>Silakan klik tautan berikut untuk mengatur ulang kata sandi Anda:</p>";
            $email_body .= "<p><a href='" . htmlspecialchars($reset_link) . "'>" . htmlspecialchars($reset_link) . "</a></p>";
            $email_body .= "<p>Tautan ini akan kedaluwarsa dalam 1 jam.</p>";
            $email_body .= "<p>Jika Anda tidak meminta ini, abaikan saja email ini.</p>";
            $email_body .= "<p>Terima kasih,<br>Tim Bedjo Garage</p>";
            $email_body .= "</body></html>";

            // Fungsi mail() PHP memerlukan konfigurasi server email (SMTP)
            // Di lingkungan lokal (XAMPP/WAMP), Anda mungkin perlu mengonfigurasi sendmail/mailhog
            // Untuk deployment, gunakan layanan seperti SendGrid, Mailgun, dll. dengan PHPMailer.
            if (mail($to, $subject, $email_body, $headers)) {
                $message = "Link reset kata sandi telah dikirim ke email Anda. Silakan cek kotak masuk Anda.";
                $message_type = 'success';
            } else {
                $message = "Gagal mengirim email reset kata sandi. Silakan coba lagi nanti.";
                $message_type = 'error';
                // Debugging: echo error_get_last()['message'];
            }
        } else {
            $message = "Terjadi kesalahan. Silakan coba lagi.";
            $message_type = 'error';
        }
        $stmt_update->close();
    } else {
        $message = "Jika email Anda terdaftar, link reset kata sandi akan dikirim.";
        $message_type = 'success'; // Beri pesan umum untuk alasan keamanan (menghindari enumerasi email)
    }
    $stmt->close();
}

include 'header.php';
?>

<main class="main-content">
    <div class="container auth-form-container">
        <h2>Lupa Kata Sandi?</h2>
        <?php if (!empty($message)): ?>
            <p class="<?php echo $message_type; ?>-message"><?php echo $message; ?></p>
        <?php endif; ?>
        <form action="forgot_password.php" method="POST" class="auth-form">
            <div class="form-group">
                <input type="email" id="email" name="email" placeholder="Masukan Email Anda" required>
            </div>
            <button type="submit" class="btn btn-primary btn-full-width">Kirim Link Reset</button>
            <p class="auth-links">
                <a href="login.php">Kembali ke halaman Masuk</a>
            </p>
        </form>
    </div>
</main>

<?php include 'footer.php'; ?>