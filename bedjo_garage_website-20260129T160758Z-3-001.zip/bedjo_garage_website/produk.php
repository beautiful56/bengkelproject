<?php 
session_start();
include 'header.php'; 
include 'db_connect.php'; // Sertakan koneksi database

// Cek metode sorting dari URL
$sort_order_sql = ' ORDER BY id ASC'; // Urutan default
$sort_order_get = $_GET['sort'] ?? 'popular';

if ($sort_order_get == 'price-desc') {
    $sort_order_sql = ' ORDER BY price DESC';
} elseif ($sort_order_get == 'price-asc') {
    $sort_order_sql = ' ORDER BY price ASC';
}

// Ambil data produk dari database
$products_result = $conn->query("SELECT * FROM products" . $sort_order_sql);

?>

<main class="main-content">
    <div class="container content-card">
        
        <div class="page-header">
            <h1>Produk Oli Shell Pilihan</h1>
            <p>Temukan oli Shell terbaik untuk performa maksimal dan perlindungan optimal motor Anda.</p>
        </div>

        <form action="produk.php" method="GET" id="filter-form">
            <div class="product-filters">
                <div class="filter-group">
                    <label for="sort-filter">Urutkan:</label>
                    <select id="sort-filter" name="sort">
                        <option value="popular" <?php if ($sort_order_get == 'popular') echo 'selected'; ?>>Terpopuler</option>
                        <option value="price-asc" <?php if ($sort_order_get == 'price-asc') echo 'selected'; ?>>Harga Terendah</option>
                        <option value="price-desc" <?php if ($sort_order_get == 'price-desc') echo 'selected'; ?>>Harga Tertinggi</option>
                    </select>
                </div>
            </div>
        </form>

        <div class="product-grid">
            <?php while($product = $products_result->fetch_assoc()): ?>
                <div class="product-card">
                    <div class="product-image-container">
                        <img src="<?php echo htmlspecialchars($product['image_url']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                    </div>
                    <div class="product-info">
                        <h3 class="product-name"><?php echo htmlspecialchars($product['name']); ?></h3>
                        <p class="product-volume"><?php echo htmlspecialchars($product['volume']); ?></p>
                        <p class="product-price">Rp <?php echo number_format($product['price'], 0, ',', '.'); ?></p>
                    </div>
                    <div class="product-actions">
                        <a href="buy_product.php?product_id=<?php echo $product['id']; ?>" class="btn-add-to-cart">
                            <i class="fas fa-bolt"></i> Beli Sekarang
                        </a>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</main>

<?php include 'footer.php'; ?>