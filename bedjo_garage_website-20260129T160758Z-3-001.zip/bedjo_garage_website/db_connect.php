<?php
// db_connect.php

$servername = "localhost";
$username = "root";      // Username MySQL Anda
$password = "";          // Password MySQL Anda (biasanya kosong jika belum diatur)
$dbname = "bedjo_garage_db"; // Harus sama dengan nama database yang Anda buat

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
