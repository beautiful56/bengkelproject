<?php
// Pastikan session dimulai HANYA jika belum dimulai
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include 'db_connect.php'; // Sertakan koneksi database

$message = '';
$message_type = ''; // 'success' or 'error'
$user_id = $_SESSION['user_id'] ?? null; // Ambil user_id dari session

// Pastikan user sudah login, jika tidak, redirect ke halaman login
if (!isset($user_id)) {
    $_SESSION['redirect_after_login'] = 'booking.php'; // Simpan URL ini untuk kembali setelah login
    header("Location: login.php");
    exit();
}

// Ambil daftar service dari database (untuk dropdown Jenis Service)
$available_services = [];
$services_result = $conn->query("SELECT id, name, base_price FROM services ORDER BY name ASC");
if ($services_result) {
    while ($row = $services_result->fetch_assoc()) {
        $available_services[] = $row;
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['confirm_booking'])) {
    // Ambil dan bersihkan input dari kedua langkah form
    $service_id = $conn->real_escape_string($_POST['service_id']);
    $booking_date = $conn->real_escape_string($_POST['booking_date']);
    $engine_cc = $conn->real_escape_string($_POST['engine_cc']);
    $vehicle_make = $conn->real_escape_string($_POST['vehicle_make']);
    $vehicle_model = $conn->real_escape_string($_POST['vehicle_model']);
    $license_plate = $conn->real_escape_string($_POST['license_plate']);
    $notes = $conn->real_escape_string($_POST['notes']);

    if (empty($service_id) || empty($booking_date) || empty($engine_cc) || empty($vehicle_make) || empty($vehicle_model) || empty($license_plate)) {
        $message = "Mohon lengkapi semua kolom yang wajib diisi.";
        $message_type = 'error';
    } else {
        $stmt_service = $conn->prepare("SELECT name, base_price FROM services WHERE id = ?");
        $stmt_service->bind_param("i", $service_id);
        $stmt_service->execute();
        $service_info = $stmt_service->get_result()->fetch_assoc();
        $stmt_service->close();

        if ($service_info) {
            $service_name = $service_info['name'];
            $base_price = $service_info['base_price'];
            $final_price = $base_price;
            if ($engine_cc == 'above_150cc') {
                $final_price += 100000;
            }

            $stmt = $conn->prepare("INSERT INTO bookings (user_id, service_type, booking_date, booking_time, vehicle_make, vehicle_model, license_plate, notes, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Pending Payment')");
            $stmt->bind_param("isssssss", $user_id, $service_name, $booking_date, $engine_cc, $vehicle_make, $vehicle_model, $license_plate, $notes);

            if ($stmt->execute()) {
                $last_booking_id = $conn->insert_id;
                header("Location: payment.php?booking_id=" . $last_booking_id . "&amount=" . $final_price);
                exit();
            } else {
                $message = "Gagal membuat booking. Silakan coba lagi.";
                $message_type = 'error';
            }
            $stmt->close();
        } else {
            $message = "Jenis service tidak valid.";
            $message_type = 'error';
        }
    }
}

include 'header.php';
?>

<main class="main-content">
    <div class="container content-card">
        <h1>Buat Booking Service</h1>
        <hr>

        <div class="form-stepper">
            <div class="step active" id="stepper-1">
                <div class="step-number">1</div>
                <div class="step-label">Layanan & Jadwal</div>
            </div>
            <div class="step" id="stepper-2">
                <div class="step-number">2</div>
                <div class="step-label">Detail Kendaraan</div>
            </div>
        </div>

        <?php if (!empty($message)): ?>
            <p class="message <?php echo $message_type; ?>"><?php echo $message; ?></p>
        <?php endif; ?>

        <form action="booking.php" method="POST" class="booking-form" id="bookingForm">

            <div class="form-step active" id="step1">
                <fieldset>
                    <legend>Pilih Layanan, Tanggal & Kapasitas Mesin</legend>
                    <div class="form-group">
                        <label for="service_id">Pilih Jenis Service:</label>
                        <select id="service_id" name="service_id" required>
                            <option value="" disabled selected>-- Pilih Service --</option>
                            <?php foreach ($available_services as $service): ?>
                                <option value="<?php echo $service['id']; ?>" data-base-price="<?php echo $service['base_price']; ?>">
                                    <?php echo htmlspecialchars($service['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="booking_date">Tanggal Booking:</label>
                        <input type="date" id="booking_date" name="booking_date" required min="<?php echo date('Y-m-d'); ?>">
                    </div>
                    <div class="form-group">
                        <label for="engine_cc">Kapasitas Mesin (CC):</label>
                        <select id="engine_cc" name="engine_cc" required>
                            <option value="" disabled selected>-- Pilih Kapasitas --</option>
                            <option value="below_150cc">Dibawah 150cc</option>
                            <option value="above_150cc">Diatas 150cc (+ Rp 100.000)</option>
                        </select>
                    </div>
                </fieldset>

                <fieldset>
                    <legend>Estimasi Biaya</legend>
                    <div class="price-display">
                        <span>Harga Service:</span>
                        <span class="final-price">Rp 0</span>
                    </div>
                </fieldset>

                <fieldset>
                    <legend>Lokasi Bengkel</legend>
                    <div class="location-info">
                        <p><strong>Bedjo Garage (Racing Team)</strong></p>
                        <a href="https://g.co/kgs/ScTz7GE" target="_blank" class="map-link">
                            <i class="fas fa-map-marker-alt"></i> Lihat di Google Maps
                        </a>
                    </div>
                </fieldset>

                <div class="form-navigation-buttons">
                    <button type="button" class="btn btn-primary btn-full-width" id="nextStep">Selanjutnya</button>
                </div>
            </div>

            <div class="form-step" id="step2" style="display: none;">
                <fieldset>
                    <legend>Detail Kendaraan & Catatan</legend>
                    <div class="form-group">
                        <label for="vehicle_make">Merk Kendaraan:</label>
                        <input type="text" id="vehicle_make" name="vehicle_make" placeholder="Contoh: Yamaha" required>
                    </div>
                    <div class="form-group">
                        <label for="vehicle_model">Tipe Kendaraan:</label>
                        <input type="text" id="vehicle_model" name="vehicle_model" placeholder="Contoh: NMAX" required>
                    </div>
                    <div class="form-group">
                        <label for="license_plate">Plat Nomor:</label>
                        <input type="text" id="license_plate" name="license_plate" placeholder="Contoh: B 1234 ABC" required>
                    </div>
                    <div class="form-group">
                        <label for="notes">Catatan Tambahan (Opsional):</label>
                        <textarea id="notes" name="notes" rows="4" placeholder="Misal: Cek bagian rem, ada bunyi aneh..."></textarea>
                    </div>
                </fieldset>
                
                <div class="form-navigation-buttons space-between">
                    <button type="button" class="btn btn-secondary" id="prevStep">Sebelumnya</button>
                    <button type="submit" name="confirm_booking" class="btn btn-primary">Konfirmasi & Lanjut Bayar</button>
                </div>
            </div>
        </form>
    </div>
</main>

<?php include 'footer.php'; ?>